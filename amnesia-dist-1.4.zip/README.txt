AMNESIA: Analysis for Monitoring and NEutralizing SQL Injection Attacks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Authors: William G.J. Halfond and Alessandro Orso
Affiliation: Georgia Institute of Technology
Technical Contact: William Halfond <whalfond@cc.gatech.edu>

This document contains installation and usage instructions for AMNESIA.
Please refer to our ASE 2005 or WODA 2005 papers for a high-level description of the AMNESIA approach.


Required JRE:
^^^^^^^^^^^^^
Java 1.5+

As of this time, AMNESIA can not be run on applications whose bytecode is compiled with Java1.5+.
This is because the JSA library that AMNESIA uses is not yet compatible with Java1.5+.
However, running AMNESIA itself requires Java 1.5+


Explanation of amnesia.properties:
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
At runtime, the properties file should be placed in the classpath of the deployed web application.
There are three properties that can be set via the properties file.  These are:
	runtime.monitor = [name of the class that will implement the monitor functionality]
	dir.aut = [relative or absolute path to directory that will contains amnesia models.
			if this is relative, it is assumed to be on the classpath of the web application]
	dir.imgs = [relative or absolute path to directory that will contains dotty files of amnesia models.
			if this is relative, it is assumed to be on the classpath of the web application]



Explanation of application XML file:
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AMNESIA instruments an application based on settings passed into it via an XML configuration file.
The base element <application> has two attributes "name," which is the name of the application, and "basedir," which specifies the absolute path to the base directory where the application is located.
The <classlist> element contains a list of <class> tags. Each <class> tag has two attributes, "name" and "target."
The attribute "name" specifies the fully qualified name of the class, and the attribute "target" specifies the URL target name.
An example "bookstore.xml" is included with this distribution.


Running AMNESIA:
^^^^^^^^^^^^^^^^
AMNESIA can be run using the amnesia.sh script. You will need to modify the four variables defined in the shell script to match your system.

properties: required and must specify the relative or absolute path to the amnesia properties file.  

config: required and must specify the relative or absolute path to the application file.  

classdir: required and must specify the absolute path to the base directory that contains all of the classes to be instrumented.

servletlib: optional, must point to libraries that define the web framework classes.
For example, if your web application runs on Tomcat, these must include the Jar files in the tomcat/common/lib that provide the implementation of the servlet libraries.
You can also provide a stub library for these classes instead as is done with the provided script.
This will make the static analysis faster.


Logging is performed using the standard Java logging interface.  AMNESIA outputs to two logs: 
"amnesia.errors" receives runtime and configuration errors messages, and "amnesia.sqlia" receives notifcations of attacks detected.
If you are running AMNESIA in a standard Tomcat configuration, these can be configured using the logging.properties file.
By default, log messages normally appear in the catalina log, but this varies by individual configurations.

