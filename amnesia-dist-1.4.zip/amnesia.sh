#! /bin/sh

properties=amnesia.properties
config=bookstore.xml
classdir=/home/whalfond/Research/Applications/bookstore/build/baseline/WEB-INF/classes
servletlib=lib/stublibraries.jar

java -Xmx1000m -Xss1024k -cp amnesia-1.3.jar:$servletlib amnesia.amnesia $properties $config $classdir
